$(document).ready(function () {
    //	$(".open-shareddoc-tbl").tablesorter(); 
    $(".open-shareddoc-tbl").tablesorter({
        // theme : 'blue',
        // cssInfoBlock : "tablesorter-no-sort",
        // widgets: [ 'zebra', 'stickyHeaders' ]
    });
    $.ajax({
        url: "library_list.json", success: function (result) {
            if (result.content.values.length == 0) {
                $('.open-shareddoc-tbl tbody').append("<tr><td colspan='5'><p>No data available<p></td></tr>");
            }
            else {
                var topicNames = [];
                var topicCount = {};
                var tableData = result.content.values;
                result.content.values.forEach(function (data, i) {
                    if (data.topicName) { topicNames.push(data.topicName); }
                    topicNames = topicNames.filter(function (item, pos) {
                        return topicNames.indexOf(item) == pos;
                    })
                });
                topicNames.push('Empty');
                topicNames.map((v, i) => topicCount[v] = 0);
                function getCount(topicCount, tableData) {
                    tableData.map((v, i) => {
                         Object.keys(topicCount).map((value,index)=>{
                             if(v.topicName.indexOf(value)!=-1){
                                 topicCount[value]+1;
                             }
                         })   
                    })
                }

                console.log(topicNames);
                topicNames.forEach(function (topicName, i) {
                    var resulttbody = "";
                    resulttbody = resulttbody + '<tbody><tr class="accordion" role="row" style="display: table-row;"><th colspan="100" class="ms-gb" nowrap=""><img src="/_layouts/images/blank.gif" alt="" height="1" width="0"><a href="javascript:"> <span class="glyphicon glyphicon-plus"></span><span>Topic :</span></a>&nbsp;<a href="javascript:">' + topicName + '</a> <span>&lrm;()</span></th></tr></tbody>';
                    resulttbody = resulttbody + '<tbody aria-live="polite" aria-relevant="all">';
                    resulttbody = addContent(resulttbody, topicName);
                    resulttbody = resulttbody + '</tbody>';
                    $('.open-shareddoc-tbl').append(resulttbody);
                })
                function addContent(resulttbody, topicName) {
                    result.content.values.forEach(function (data, i) {
                        if (topicName == data.topicName) {
                            resulttbody = resulttbody + '"<tr><td></td><td><a href="">"' + data.docName + ' "</a></td><td>" ' + data.subTopicName + '"</td><td>" ' + data.globalRegionNames + '"</td><td>" ' + data.countryNames + '"</td><td>' + data.varietyNames + '</td><td>"' + data.author + '"</td><td>" ' + data.dateUploaded + ' "</td><td>"' + data.docType + '"</td><td><a href="" data-toggle="modal" data-target="#edit-doc-modal">Edit</a></td><td> <a href="">Delete</a></td></tr>';
                        } else if (topicName == 'Empty' && data.topicName == undefined) {
                            resulttbody = resulttbody + '"<tr><td></td><td><a href="">"' + data.docName + ' "</a></td><td>" ' + data.subTopicName + '"</td><td>" ' + data.globalRegionNames + '"</td><td>" ' + data.countryNames + '"</td><td>' + data.varietyNames + '</td><td>"' + data.author + '"</td><td>" ' + data.dateUploaded + ' "</td><td>"' + data.docType + '"</td><td><a href="" data-toggle="modal" data-target="#edit-doc-modal">Edit</a></td><td> <a href="">Delete</a></td></tr>';
                        }
                    })
                    console.log(result.content.values);

                    return resulttbody
                }
            }
            $(function () {
                $(".open-shareddoc-tbl tbody tr.accordion,.approve-doc-tbl tbody tr.accordion").show();
                $(".open-shareddoc-tbl tbody tr:not(.accordion),.approve-doc-tbl tbody tr:not(.accordion)").hide();
                $(".open-shareddoc-tbl tr.accordion,.approve-doc-tbl tr.accordion").on('click', function () {
                    //$(this).find().closest('tbody').next().toggle();
                    $(this).parent().next().find('tr').toggle();
                    if ($(this).find('.glyphicon').hasClass('glyphicon-plus')) {
                        $(this).find('.glyphicon').removeClass('glyphicon-plus').addClass('glyphicon-minus');
                    }
                    else if ($(this).find('.glyphicon').hasClass('glyphicon-minus')) {
                        $(this).find('.glyphicon').removeClass('glyphicon-minus').addClass('glyphicon-plus');
                    }
                })
            });
        }
    });
})
