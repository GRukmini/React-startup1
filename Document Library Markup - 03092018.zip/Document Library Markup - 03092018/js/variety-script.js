$(document).ready(function () {
    $('.datepicker').datepicker({
    
});
  
    loadAllVarieties();
    function loadAllVarieties() {
        $.ajax({
            url: "js/variety-info.json", success: function (result) {

                if (result.content.values.length == 0) {
                    $('.variety-list-tbl tbody').append("<tr><td colspan='5'><p>No data available<p></td></tr>");
                }
                else {
                    result.content.values.forEach(function (data, i) {
                        var comDate = data["firstSaleDate"];
                        var reqDate = comDate ? comDate.slice(0, 12) : "";
                        var varnameData = data["varName"] == undefined ? "" : data["varName"];
                        var countryName = data["cntryName"] == undefined ? "" : data["cntryName"];
                        var commentsData = data["comments"] == undefined ? "" : data["comments"];
                        $('.variety-list-tbl tbody').append("<tr><td><a href='/VarietyDetails.html'>" + varnameData + "</a></td><td>" + reqDate + "</td><td>" + countryName + "</td><td>" + commentsData + "</td></tr>");
$('#add-vareity-model #variety-name').append('<option value="' +varnameData + '">' + varnameData + '</option>')
                        
                    });
                }
            }
        });
    }

    $.ajax({
        url: "js/country.json", success: function (result) {
            result.values.forEach(function (data) {
                $('#select-country-drpdwn').append('<option value="' + data["id"] + '">' + data["name"] + '</option>');

                $('#country-of-fwws').append('<option value="' + data["id"] + '">' + data["name"] + '</option>');
            });

        }
    });
    $(".variety-details-tbl").stupidtable();
    $("#select-country-drpdwn").change(function () {
        var selectedValue = $(this).val()
        loadCountryData(selectedValue);
        $('tbody').html('');
    })
    function loadCountryData(selectedValue) {
        console.log(selectedValue);
        if (selectedValue == 0) {
            loadAllVarieties();
        }
        else {
            $.ajax({
                url: "js/country" + selectedValue + ".json",
                success: function (result) {
                    result.content.values.forEach(function (data, i) {
                        var comDate = data["firstSaleDate"];
                        var reqDate = comDate ? comDate.slice(0, 12) : "";
                        var varnameData = data["varName"] == undefined ? "" : data["varName"];
                        var countryName = data["cntryName"] == undefined ? "" : data["cntryName"];
                        var commentsData = data["comments"] == undefined ? "" : data["comments"];
                        $('tbody').append("<tr><td><a href=''>" + varnameData + "</a></td><td>" + reqDate + "</td><td>" + countryName + "</td><td>" + commentsData + "</td></tr>");
                    });

                }
            });
        }
    }

    $('.add-variety-submit').on('click', function () {
        $('.modal,.modal-backdrop').hide();
        var variety = $('.variety-name').val();
        var dateOfFwWS = $('.date-of-fwws').val();
        var countryOfFwws = $('.country-of-fwws :selected').text();
        var varityComments = $('#variety-comments').val();
     
       $('.variety-list-tbl tbody').append("<tr><td><a href=''>" + variety + "</a></td><td>" + dateOfFwWS + "</td><td>" + countryOfFwws + "</td><td>" + varityComments + "</td></tr>");
      /*  jQuery.ajax({
            type: 'POST',
            headers: {
                Accept: "application/json; charset=utf-8",
                "Content-Type": "application/json; charset=utf-8"
            },
            data: responsse,
            url: "",
            contentType: 'application/json',
            dataType: 'json',
            success: function (response) {
                location.reload();
            }
        });*/
    })

    
})
